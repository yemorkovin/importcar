
<?php $__env->startSection('title', 'Авто из Европы'); ?>
<?php $__env->startSection('content'); ?>
<div class="content_main">
		<div class="content_main_catalog"> 
		<div class="menu_left">
			<h3>Марка автомобиля</h3>
			<ul>
				<!--<li class="active_filter"><a href="#" >Volkswagen</a></li>-->
				<li id="v_1"><a href="#" >Volkswagen</a></li>
				<li id="v_1"><a href="#">BMW</a></li>
				<li id="v_1"><a href="#">Audi</a></li>
			</ul>
			<h3>Коробка передач</h3>
			<ul>
				<li id="v_2"><a href="#">Автомат</a></li>
				<li id="v_2"><a href="#">Механика</a></li>
			</ul>
			<h3>Тип топлива</h3>
			<ul>
				<li id="v_3"><a href="#" >Бензин</a></li>
				<li id="v_3"><a href="#">Дизель</a></li>
			</ul>
			<h3>Год выпуска</h3>
			<ul>
				<li id="v_4"><a href="#" >1999</a></li>
				<li id="v_4"><a href="#">2000</a></li>
			</ul>
		</div>
		<div class="catalog_main_item">
			<div class="actual_catalog actual_catalog_catalog">
		
			<h2 class="h2_catalog">Каталог авто</h2>
			<div class="filter_mobile">
				<p>Фильтр автомобилей</p>
				<img src="assets/img/filter.png" class="img_filter_click" alt="">
			</div>
			<div class="actual_catalog_flex flex_wrap cat_act_m">
			<?php $__currentLoopData = $catalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="actual_catalog_item actual_catalog_item25">
					<img src="/storage/<?php echo e($ca->img); ?>">
					<p class="h_item_fl"><?php echo e($ca->title); ?></p>
					<p class="catalog_description"><?php echo e($ca->desc); ?></p>
					<p class="price_new"><?php echo e($ca->price_new); ?> ₽</p>
					<p class="price_old"><?php echo e($ca->price_old); ?> ₽</p>
					<button class="btn_order_catalog" onclick="document.location.href = '/catalog/<?php echo e($ca->id); ?>';">Подробнее</button>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>
			
	</div>	
		</div>
	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\new.loc\resources\views/catalog.blade.php ENDPATH**/ ?>