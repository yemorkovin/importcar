
<?php $__env->startSection('title', 'Авто из Европы'); ?>
<?php $__env->startSection('content'); ?>
<br /><br /><br /><br /><br /><br />
	<div style="padding: 20px">
		<h2><?php echo e($one_catalog->title); ?></h2>
		<p style="float: left;margin: 10px"><img src="/storage/<?php echo e($one_catalog->img); ?>"></p>
		<p><b>Описание: </b><?php echo e($one_catalog->desc); ?></p>
		<p><b>Полный текст: </b><?php echo e($one_catalog->text_full); ?></p>
		<p><b>Марка: </b><?php echo e($one_catalog->marka); ?></p>
		<p><b>Коробка передач: </b><?php echo e($one_catalog->korobka); ?></p>
		<p><b>Тип топлива:</b><?php echo e($one_catalog->type_toplivo); ?></p>
		<p><b>Год: </b><?php echo e($one_catalog->year); ?></p>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\new.loc\resources\views/one_catalog.blade.php ENDPATH**/ ?>