 
<?php $__env->startSection('title', 'Об авторе'); ?>
<?php $__env->startSection('description', "Блог Евгения Морковина"); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content-container">
        <div class="main-container">
            <div class="article">
                <div class="breadcrumbs">
                    <ul class="breadcrumbs__list">
                        <a class="breadcrumbs__link" href="/">Главная   </a>
                       
                        <a class="breadcrumbs__link">Об авторе</a>
                    </ul>
                </div>
                <h1 class="article__title">Об авторе</h1>
                <div class="short__row article__short">
                   
                    
                </div>
               
                
                <div class="article__content">
                    <div class="editor-js-content"><div class="editor-js-block">
    <div class="entry-content">
				<p>
</p>



<p>Здравствуйте! Меня зовут <strong>Евгений</strong> <strong>Морковин</strong>, и я являюсь создателем и главным администратором сайта&nbsp;<strong>DevOpser.online</strong>, который посвящён теме&nbsp;программирования и системного администрирования.</p>



<p>Мне ОЧЕНЬ приятно, что у нас с Вами общие интересы, и поэтому Вы решили посетить мой сайт!</p>



<p>Немного о себе.</p>



<p>Окончил <strong>Харьковский национальный университет радиоэлектроники </strong>, факультет&nbsp;<strong>Инфокомуникации</strong>. Учился на бюджетной основе, причём вполне успешно (диплом с отличием). После чего поступил в аспирантуру.</p>



<p>Программированием увлёкся ещё в&nbsp;<strong>колледже</strong>. Начинал с&nbsp;<strong>Turbo Pascal</strong>, потом познакомился с созданием сайтов, программированием микроконтроллеров.</p>



<p><strong>На 1-ом курсе</strong>&nbsp;университета увлекся ардуино, где мы с братом реализовали макет «умного дома» и заняли призовое место на конкурсе!</p>



<p><strong>Последующие годы, учась в университете, </strong>изучал&nbsp;<strong>Python</strong>.</p>



<p>Потом вернулся к&nbsp;<strong>создани</strong><strong>ю</strong><strong> сайтов</strong>. Изучил&nbsp;<strong>HTML</strong>,&nbsp;<strong>CSS</strong>,&nbsp;<strong>JavaScript</strong>,&nbsp;<strong>PHP</strong>,&nbsp;<strong>SQL (пользовался ПО MySQL).</strong></p>



<p>После окончания вуза устроился в колледж на должность системного администратора, где увлекся данной сферой деятельности! Одновременно работал фрилансером, выполняя работу по созданию сайтов.</p>



<p>Вот и вся информация обо мне.</p>



<p><strong>С удовольствием отвечу на любые Ваши вопросы!</strong></p>
<p></p>
			</div>
</div>
</div>
                </div>
                
                
                
               
            </div>
        </div>

        <div class="sidebar">

    <div class="feed">
        <div class="feed__title">
            Топ-уроки
        </div>
            <a class="feed__stock conversion-paid" rel="nofollow" target="_blank" href="https://repetitor.yemorkovin.ru/courses/php">
                <div class="feed__stock-title">
                    PHP с 0 до гуру
                </div>
                <div class="feed__stock-headline">
                    Скидка при покупке от 3 уроков
                </div>
                <div class="btn btn--border">
                    Подробнее
                </div>
            </a>
             <a class="feed__stock conversion-paid" rel="nofollow" target="_blank" href="https://repetitor.yemorkovin.ru/courses/python">
                <div class="feed__stock-title">
                    Python с 0 до гуру
                </div>
                <div class="feed__stock-headline">
                    Скидка при покупке от 3 уроков
                </div>
                <div class="btn btn--border">
                    Подробнее
                </div>
            </a>
             <a class="feed__stock conversion-paid" rel="nofollow" target="_blank" href="https://repetitor.yemorkovin.ru/">
                <div class="feed__stock-title">
                    Laravel
                </div>
                <div class="feed__stock-headline">
                    Скидка при покупке от 3 уроков
                </div>
                <div class="btn btn--border">
                    Подробнее
                </div>
            </a>
            <a class="feed__stock conversion-paid" rel="nofollow" target="_blank" href="https://repetitor.yemorkovin.ru/">
                <div class="feed__stock-title">
                    Django
                </div>
                <div class="feed__stock-headline">
                    Скидка при покупке от 3 уроков
                </div>
                <div class="btn btn--border">
                    Подробнее
                </div>
            </a>
            </div>
    <div class="feed feed--glass">
        
        
    </div>
           
    </div> 
         </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\new.loc\resources\views/obavtore.blade.php ENDPATH**/ ?>