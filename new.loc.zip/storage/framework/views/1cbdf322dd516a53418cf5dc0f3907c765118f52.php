<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Nunito+Sans:opsz,wght@6..12,400;6..12,600;6..12,700;6..12,800&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="public/src/css/itc-slider.css" />
    <script src="public/src/js/itc-slider.min.js" defer></script>
    <link rel="stylesheet" href="public/src/css/style.css" />

    <title><?php echo $__env->yieldContent('title'); ?></title>
  </head>
  <!-- class="noscroll" -->
  <body>
    <div class="leave_request_panel__wrapper">
      <div class="leave_request_panel">
        <div class="leave_request_panel__logo">
          <img src="public/src/img/logos/site.svg" />
        </div>
        <div
          class="leave_request_panel__close"
          onclick="setVisibleLeaveRequestPanel(false)"
        >
          <img src="public/src/img/icons/close.svg" />
        </div>

        <div class="leave_request_panel_comp">
          Аренда контейнера от 7 до 30 кубов.
        </div>
        <div class="leave_request_panel__border">
          <div class="leave_request_panel__title">
            <label class="leave_request_panel__title__1">Заявка</label>
            <label class="leave_request_panel__title__2">
              Укажите ваши данные и мы Вам перезвоним
            </label>
          </div>
          <div id="res"></div>
          <form id="formord">
            <div class="form__line">
              <label for="inp" class="inp">
                <input type="text" id="fio" placeholder="&nbsp;" />
                <span class="label">Ваше имя</span>
                <span class="focus-bg"></span>
              </label>
            </div>
            <div class="form__line">
              <label for="inp" class="inp">
                <input type="text" id="phone_number" placeholder="&nbsp;" />
                <span class="label">Телефон</span>
                <span class="focus-bg"></span>
              </label>
            </div>
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" id="token" name="">
            <input type="hidden" value="<?=$_SERVER["HTTP_REFERER"]??''?>" id="ref">
            <input type="hidden" value="" id="mode">
            <button class="btn">Отправить</button>
          </form>
        </div>
      </div>
    </div>
    <div class="sky_background">
      <img src="public/src/img/pictures/sky.png" />
    </div>
    <div class="tree_2">
      <img src="public/src/img/pictures/tree_2.png" />
    </div>
    <div class="tree_3">
      <img src="public/src/img/pictures/tree_3.png" />
    </div>
    <div class="tree_4">
      <img src="public/src/img/pictures/tree_4.png" />
    </div>
    <div class="left_text_wrapper">
      <div class="left_text_wrapper__img_1">
        <img src="public/src/img/pictures/left_text_1.svg" />
      </div>
      <div class="left_text_wrapper__img_2">
        <img src="public/src/img/pictures/left_text_2.svg" />
      </div>
      <div class="left_text_wrapper__img_3">
        <img src="public/src/img/pictures/left_text_3.svg" />
      </div>
      <div class="left_text_wrapper__img_4">
        <img src="public/src/img/pictures/left_text_4.svg" />
      </div>
      <div class="left_text_wrapper__img_5">
        <img src="public/src/img/pictures/left_text_5.svg" />
      </div>
      <div class="left_text_wrapper__img_6">
        <img src="public/src/img/pictures/left_text_6.svg" />
      </div>
    </div>
    <div class="sheets">
      <div class="sheet_1"><img src="public/src/img/pictures/sheet_1.png" /></div>
      <div class="sheet_2"><img src="public/src/img/pictures/sheet_2.png" /></div>
      <div class="sheet_3"><img src="public/src/img/pictures/sheet_2.png" /></div>
      <div class="sheet_4"><img src="public/src/img/pictures/sheet_3.png" /></div>
      <div class="sheet_5"><img src="public/src/img/pictures/sheet_2.png" /></div>
      <div class="sheet_6"><img src="public/src/img/pictures/sheet_2.png" /></div>
      <div class="sheet_7"><img src="public/src/img/pictures/sheet_3.png" /></div>
    </div>

    <a href="tel:+74012520510" class="info_panel__right__phone">
      <div class="info_panel__right__phone__img">
        <img src="public/src/img/icons/phone.svg" />
      </div>
    </a>
    <div class="body_wrapper">
      <header class="header">
        <div class="center_panel">
          <!-- info panel -->
          <div class="info_panel">
            <div class="info_panel__left">
              <div class="info_panel__logo">
                <img src="public/src/img/logos/site.svg" />
              </div>
              <div class="info_panel__location">
                <div class="info_panel__location__icon">
                  <img src="public/src/img/icons/marker_pin.svg" />
                </div>
                <label>Калининград и область</label>
              </div>
            </div>
            <div class="info_panel__right">
              <a href="#" class="telegram_link">
                <div class="telegram_link__icon">
                  <img src="public/src/img/logos/telegram.svg" />
                </div>
                <label>Мы в Telegram</label>
              </a>
              <div class="info_panel__right__number">
                <label class="info_panel__right__number__title">
                  +7 (4012) 520-510
                </label>
                <div class="info_panel__right__number__subtitle">
                  <div class="info_panel__right__number__subtitle__img">
                    <img src="public/src/img/icons/ellipse_point.svg" />
                  </div>
                  <label>Пн-Вс с 8:00 до 22:00</label>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="line"></div>
        <div class="center_panel">
          <!-- navigation -->
          <div class="navigation">
            <nav class="navigation__nav">
              <ul class="navigation__ul">
                <li class="navigation__li">
                  <a href="#types_containers" class="navigation__link">
                    Виды контейнеров
                  </a>
                </li>
                <li class="navigation__li">
                  <a href="#types_waste" class="navigation__link">
                    Виды отходов
                  </a>
                </li>
                <li class="navigation__li">
                  <a href="#reasons_section" class="navigation__link">
                    Почему мы
                  </a>
                </li>
                <li class="navigation__li">
                  <a href="#reasons_apply" class="navigation__link">
                    Схема работы
                  </a>
                </li>
                <li class="navigation__li">
                  <a href="#answers" class="navigation__link">Отзывы</a>
                </li>
                <li class="navigation__li">
                  <a href="#car_park" class="navigation__link">Наш автопарк</a>
                </li>
                <li class="navigation__li">
                  <a href="#more_about" class="navigation__link">Об услуге</a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </header>
      <?php echo $__env->yieldContent('content'); ?>
      <footer class="footer">
        <div class="center_panel">
          <div class="info_panel">
            <div class="info_panel__left">
              <div class="info_panel__logo">
                <img src="public/src/img/logos/site.svg" />
              </div>
              <div class="info_panel__location">
                <div class="info_panel__location__icon">
                  <img src="public/src/img/icons/marker_pin.svg" />
                </div>
                <label>Калининград и область</label>
              </div>
            </div>
            <div class="info_panel__right">
              <a href="#" class="telegram_link">
                <div class="telegram_link__icon">
                  <img src="public/src/img/logos/telegram.svg" />
                </div>
                <label>Мы в Telegram</label>
              </a>
              <div class="info_panel__right__number">
                <label class="info_panel__right__number__title">
                  +7 (4012) 520-510
                </label>
                <div class="info_panel__right__number__subtitle">
                  <div class="info_panel__right__number__subtitle__img">
                    <img src="public/src/img/icons/ellipse_point.svg" />
                  </div>
                  <label>Пн-Вс с 8:00 до 22:00</label>
                </div>
              </div>
            </div>
          </div>
          <div class="navigation">
            <nav class="navigation__nav">
              <ul class="navigation__ul">
                <li class="navigation__li">
                  <a href="#types_containers" class="navigation__link">
                    Виды контейнеров
                  </a>
                </li>
                <li class="navigation__li">
                  <a href="#types_waste" class="navigation__link">
                    Виды отходов
                  </a>
                </li>
                <li class="navigation__li">
                  <a href="#reasons_section" class="navigation__link">
                    Почему мы
                  </a>
                </li>
                <li class="navigation__li">
                  <a href="#reasons_apply" class="navigation__link">
                    Схема работы
                  </a>
                </li>
                <li class="navigation__li">
                  <a href="#answers" class="navigation__link">Отзывы</a>
                </li>
                <li class="navigation__li">
                  <a href="#car_park" class="navigation__link">Наш автопарк</a>
                </li>
                <li class="navigation__li">
                  <a href="#more_about" class="navigation__link">Об услуге</a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <div class="line"></div>
        <div class="center_panel">
          <section class="footer_line">
            <label>© 2023, МУСОРВОЗИМ</label>
            <label>Политика обработки персональных данных</label>
          </section>
        </div>
      </footer>
    </div>
    <script src="public/src/js/script.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js" integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js"></script>
    <script>
      // Инициализация маски для поля ввода номера телефона
      $(document).ready(function() {
        $('#res').hide();
        $('#phone_number').inputmask('+7 (999) 999-99-99');
        $('#formord').on('submit', function(event) {
            event.preventDefault();
          // Проверяем, заполнена ли маска полностью
          if (!$('#phone_number').inputmask('isComplete')) {
            // Если маска не заполнена полностью, предотвращаем отправку формы
            
            alert('Пожалуйста, заполните номер телефона полностью!');
          }else{
            let token = $('#token').val();
            let ref = $('#ref').val();
            let fio = $('#fio').val();
            let phone = $('#phone_number').val();

            let mode = $('#mode').val();

             $.ajax({
                url: "/ajax/form",
                type:"POST",
                data:{
                    "_token":  token,
                    fio:fio,
                    phone:phone,
                    ref:ref,
                    m:mode
                },
                success:function(response){
                    if(response !== 500){
                        //window.location = "/";
                        console.log(response);
                        if(response==1){

                            $('#formord').hide();
                            $('#res').text('Данные успешно отправлены!');
                            $('#res').show();
                        }
                    }
                },
            });
          }
        });
      });
    </script>
  </body>
</html>
<?php /**PATH D:\OpenServer\domains\pars.loc\resources\views/main.blade.php ENDPATH**/ ?>