
<?php $__env->startSection('title', 'Авто из Европы'); ?>
<?php $__env->startSection('content'); ?>
<br /><br /><br /><br /><br /><br />
	<div style="padding: 20px">
		<h2 align="center"><?php echo e($p->title); ?></h2>
			<?php echo $p->txt; ?>

	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\new.loc\resources\views/page.blade.php ENDPATH**/ ?>