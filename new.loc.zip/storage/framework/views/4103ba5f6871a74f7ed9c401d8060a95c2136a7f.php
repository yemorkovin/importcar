<!-- resources/views/voyager/custom_page.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <h1>Заявки</h1>
            <ul>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><b>ФИО:</b> <?php echo e($item->fio); ?> <b>Телефон:</b> <?php echo e($item->phone); ?> <b>Ref:</b> <?php echo e($item->ref); ?></li> <!-- Пример вывода имени из модели -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\pars.loc\resources\views/voyager/custom_page.blade.php ENDPATH**/ ?>