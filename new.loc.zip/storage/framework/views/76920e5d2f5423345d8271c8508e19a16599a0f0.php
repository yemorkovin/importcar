
<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('description', $post->meta_description); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content-container">
        <div class="main-container">
            <div class="article">
                <div class="breadcrumbs">
                    <ul class="breadcrumbs__list">
                        <a class="breadcrumbs__link" href="/">Главная   </a>
                       
                        <a class="breadcrumbs__link"><?php echo e($post->title); ?></a>
                    </ul>
                </div>
                <h1 class="article__title"><?php echo e($post->title); ?> </h1>
                <div class="short__row article__short">
                    <div class="short short--date"><?php echo e(date('d.m.Y', strtotime($post->created_at))); ?></div>
                    
                </div>
               
                
                <div class="article__content">
                    <div class="editor-js-content"><div class="editor-js-block">
    <?php echo $post->body; ?>

</div>
</div>
                </div>
                
                
                <div class="news article__news">
                    <h2 class="news__title">Читайте также</h2>
                    <div class="news__row">
                        <?php $__currentLoopData = $postread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="news__col news__col--tiny"><a class="news__col--body" href="/post/<?php echo e($postr->slug); ?>">
                                <div class="news__col-img--wrap"><img class="news__col-img" src="\storage\<?php echo e($postr->image); ?>" width="384" height="207" alt="<?php echo e($postr->title); ?>"></div>
                                <div class="news__col-info">
                                    <div class="news__col-title"><?php echo e($postr->title); ?></div>
                                    
                                    <div class="short__row">
                                        <div class="short"><?php echo e(date('d.m.Y', strtotime($postr->created_at))); ?></div>
                                        <div class="short short--views">1456</div>
                                    </div>
                                </div></a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                      
                    </div>
                </div>
                <div class="comments article__comments">
                    <div class="comments__header">
                        <h2 class="comments__title"><?php echo e($count_comments); ?></h2>
                        <label class="comments__write" for="comments-name">Написать комментарий</label>
                    </div>
                    <ul class="comments__list">
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="comments__item">
                            <div class="comments__item-header">
                                <div class="comments__item-user"><img class="comments__item-user-ava" src="/images/18601.png" width="40" height="40" alt="Имя автора">
                                    <div class="comments__item-wrapper">
                                        <div class="comments__item-user-name"><?php echo e($comment->email); ?></div>
                                        <div class="comments__item-time"><?php echo e(date('d.m.Y', strtotime($comment->created_at))); ?> в <?php echo e(date('H:i', strtotime($comment->created_at))); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="comments__item-body">
                                <div class="comments__item-msg">
                                    <p><?php echo e($comment->comment); ?></p>
                                </div>
                            </div>
                            
                        </li><br />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <form class="form comments__form" action="/addcomment" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form__group">
                            <div class="input">
                                <input class="input__elem" id="comments-name" type="text" name="name" placeholder="Ваше имя" required>
                            </div>
                            <div class="input">
                                <input class="input__elem" type="email" name="email" placeholder="Email" required>
                            </div>
                            <input type="hidden" name="id_post" value="<?php echo e($post->id); ?>">
                        </div>
                        <div class="input">
                            <textarea class="input__elem" name="comment" cols="30" rows="10" placeholder="Комментарий" required></textarea>
                        </div>
                        <div class="comments__form-footer">
                            <button class="btn btn--orange" type="submit" aria-label="Send form">Отправить комментарий</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="sidebar">

    <div class="feed">
        <div class="feed__title">
            Топ-уроки
        </div>
            <a class="feed__stock conversion-paid" rel="nofollow" target="_blank" href="https://repetitor.yemorkovin.ru/courses/php">
                <div class="feed__stock-title">
                    PHP с 0 до гуру
                </div>
                <div class="feed__stock-headline">
                    Скидка при покупке от 3 уроков
                </div>
                <div class="btn btn--border">
                    Подробнее
                </div>
            </a>
             <a class="feed__stock conversion-paid" rel="nofollow" target="_blank" href="https://repetitor.yemorkovin.ru/courses/python">
                <div class="feed__stock-title">
                    Python с 0 до гуру
                </div>
                <div class="feed__stock-headline">
                    Скидка при покупке от 3 уроков
                </div>
                <div class="btn btn--border">
                    Подробнее
                </div>
            </a>
             <a class="feed__stock conversion-paid" rel="nofollow" target="_blank" href="https://repetitor.yemorkovin.ru/">
                <div class="feed__stock-title">
                    Laravel
                </div>
                <div class="feed__stock-headline">
                    Скидка при покупке от 3 уроков
                </div>
                <div class="btn btn--border">
                    Подробнее
                </div>
            </a>
            <a class="feed__stock conversion-paid" rel="nofollow" target="_blank" href="https://repetitor.yemorkovin.ru/">
                <div class="feed__stock-title">
                    Django
                </div>
                <div class="feed__stock-headline">
                    Скидка при покупке от 3 уроков
                </div>
                <div class="btn btn--border">
                    Подробнее
                </div>
            </a>
            </div>
    <div class="feed feed--glass">
        
        
    </div>
           
    </div>    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\new.loc\resources\views/post.blade.php ENDPATH**/ ?>