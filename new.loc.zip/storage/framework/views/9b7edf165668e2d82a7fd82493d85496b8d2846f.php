
<?php $__env->startSection('title', 'МУСОРВОЗИМ'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
        <div class="hidden_main_section">
          <div class="center_panel">
            <!-- main section -->
            <section class="main_section">
              <!-- main section left -->
              <div class="main_section__left">
                <div class="main_section__left__title_panel">
                  <h3>Вывоз и утилизация строительного мусора</h3>
                  <label>в калининграде и области</label>
                </div>
                <div class="main_section__left__content">
                  <p>
                    Предоставляем качественные услуги по сбору, погрузке и
                    вывозу мусора в Калининграде и области. Основное
                    преимущество компании — современный парк надежной
                    спецтехники и квалифицированный персонал
                  </p>
                </div>
                <!-- ok panel -->
                <ul
                  class="main_section__left__ok_panel main_section__left__ok_panel_hid"
                >
                  <li class="main_section__left__ok_panel__li">
                    <div class="main_section__left__ok_panel__icon_wrapper">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Приедем в течение 1 часа</label>
                  </li>
                  <li class="main_section__left__ok_panel__li">
                    <div class="main_section__left__ok_panel__icon_wrapper">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Заберем любые объемы мусора</label>
                  </li>
                  <li class="main_section__left__ok_panel__li">
                    <div class="main_section__left__ok_panel__icon_wrapper">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Вывозим в контейнерах 8 м3 и более</label>
                  </li>
                </ul>
                <!-- btns -->
                <div class="main_section__left__btns">
                  <a href="#" class="btn">+7 (4012) 520-510</a>
                  <div
                    onclick="setVisibleLeaveRequestPanel(true)"
                    class="btn btn_not_fill"
                  >
                    Оставить заявку
                  </div>
                </div>
              </div>
              <!-- main section right -->
              <div class="main_section__right">
                <div class="main_section__right__tree">
                  <img src="public/src/img/pictures/tree_1.png" />
                </div>
                <div class="main_section__right__auto">
                  <img src="public/src/img/pictures/auto_1.png" />
                </div>
              </div>
              <ul
                class="main_section__left__ok_panel main_section__left__ok_panel_hid_2"
              >
                <li class="main_section__left__ok_panel__li">
                  <div class="main_section__left__ok_panel__icon_wrapper">
                    <img src="public/src/img/icons/ok.svg" />
                  </div>
                  <label>Приедем в течение 1 часа</label>
                </li>
                <li class="main_section__left__ok_panel__li">
                  <div class="main_section__left__ok_panel__icon_wrapper">
                    <img src="public/src/img/icons/ok.svg" />
                  </div>
                  <label>Заберем любые объемы мусора</label>
                </li>
                <li class="main_section__left__ok_panel__li">
                  <div class="main_section__left__ok_panel__icon_wrapper">
                    <img src="public/src/img/icons/ok.svg" />
                  </div>
                  <label>Вывозим в контейнерах 8 м3 и более</label>
                </li>
              </ul>
            </section>
          </div>
        </div>
        <div class="center_panel">
          <!-- types containers section -->
          <a name="types_containers"></a>
          <section class="types_containers_section">
            <h4 class="types_containers_section__title">Виды контейнеров</h4>
            <div class="types_containers_section__slots_wrapper">
              <div class="types_containers_section__slots">
                <!-- slot -->
                <div class="type_container_slot">
                  <div class="type_container_slot__wrapper">
                    <div class="type_container_slot__img">
                      <img src="public/src/img/icons/container_1.svg" />
                    </div>
                    <div class="type_container_slot__bottom">
                      <div class="type_container_slot__bottom__1">
                        <h4>Контейнер 7 м3</h4>
                        <p>
                          Компактный контейнер, который не займет много места.
                          Подходит для коммунальных и прочих отходов
                        </p>
                      </div>
                      <div class="type_container_slot__bottom__2">
                        <div class="type_container_slot__cost">
                          <label class="type_container_slot__cost__title">
                            Стоимость
                          </label>
                          <label class="type_container_slot__cost__number">
                            5 000 ₽
                          </label>
                        </div>
                        <div class="type_container_slot_btn">
                          <a  onclick="setVisibleLeaveRequestPanel(true)" class="btn">Заказать</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- slot (active) -->
                <div class="type_container_slot active">
                  <div class="type_container_slot__wrapper">
                    <div class="type_container_slot__wrapper_hit">Хит</div>
                    <div class="type_container_slot__img">
                      <img src="public/src/img/icons/container_1.svg" />
                    </div>
                    <div class="type_container_slot__bottom">
                      <div class="type_container_slot__bottom__1">
                        <h4>Контейнер 8 м3</h4>
                        <p>
                          Универсальный контейнер, который используется для
                          любого вида мусора, включая ТБО, строительный мусор и
                          другие отходы
                        </p>
                      </div>
                      <div class="type_container_slot__bottom__2">
                        <div class="type_container_slot__cost">
                          <label class="type_container_slot__cost__title">
                            Стоимость
                          </label>
                          <label class="type_container_slot__cost__number">
                            5 000 ₽
                          </label>
                        </div>
                        <div class="type_container_slot_btn">
                          <a onclick="setVisibleLeaveRequestPanel(true)" class="btn">Заказать</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- slot -->
                <div class="type_container_slot">
                  <div class="type_container_slot__wrapper">
                    <div class="type_container_slot__img">
                      <img src="public/src/img/icons/container_2.svg" />
                    </div>
                    <div class="type_container_slot__bottom">
                      <div class="type_container_slot__bottom__1">
                        <h4>Контейнер 25 м3</h4>
                        <p>
                          Контейнер увеличенного объема. Подходит как для
                          легкого, так и для крупногабаритного тяжелого мусора
                        </p>
                      </div>
                      <div class="type_container_slot__bottom__2">
                        <div class="type_container_slot__cost">
                          <label class="type_container_slot__cost__title">
                            Стоимость
                          </label>
                          <label class="type_container_slot__cost__number">
                            15 000 ₽
                          </label>
                        </div>
                        <div class="type_container_slot_btn">
                          <a onclick="setVisibleLeaveRequestPanel(true)" class="btn">Заказать</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- slot -->
                <div class="type_container_slot">
                  <div class="type_container_slot__wrapper">
                    <div class="type_container_slot__img">
                      <img src="public/src/img/icons/container_2.svg" />
                    </div>
                    <div class="type_container_slot__bottom">
                      <div class="type_container_slot__bottom__1">
                        <h4>Контейнер 30 м3</h4>
                        <p>
                          Большой контейнер используется для вывоза мусора со
                          строительных объектов, при вырубке деревьев и прочих
                          работах
                        </p>
                      </div>
                      <div class="type_container_slot__bottom__2">
                        <div class="type_container_slot__cost">
                          <label class="type_container_slot__cost__title">
                            Стоимость
                          </label>
                          <label class="type_container_slot__cost__number">
                            20 000 ₽
                          </label>
                        </div>
                        <div class="type_container_slot_btn">
                          <a onclick="setVisibleLeaveRequestPanel(true)" class="btn">Заказать</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="types_containers_section__slots_wrapper__scroll_icon">
              <img src="public/src/img/pictures/scroll_icon.svg" />
            </div>
          </section>
        </div>
        <!-- reasons -->
        <a name="reasons_section"></a>
        <section class="reasons_section">
          <div class="center_panel reasons_section__wrapper">
            <h3>6 причин, почему нам можно доверять</h3>
            <!-- reasons slots -->
            <div class="reasons_section__slots">
              <div class="reason_slot">
                <div class="reason_slot__left">
                  <img src="public/src/img/icons/thumbs_up.svg" />
                </div>
                <div class="reason_slot__right">
                  <h4>Большой автопарк</h4>
                  <p>
                    У нас машины различной грузоподъемности, что позволяет
                    вывозить отходы любого веса и габаритов
                  </p>
                </div>
              </div>
              <div class="reason_slot">
                <div class="reason_slot__left">
                  <img src="public/src/img/icons/rocket.svg" />
                </div>
                <div class="reason_slot__right">
                  <h4>Оперативность</h4>
                  <p>
                    Подадим контейнер для сбора и накопления отходов максимально
                    быстро после обращения
                  </p>
                </div>
              </div>
              <div class="reason_slot">
                <div class="reason_slot__left">
                  <img src="public/src/img/icons/trash.svg" />
                </div>
                <div class="reason_slot__right">
                  <h4>Порядок и чистота</h4>
                  <p>
                    После вывоза мусора оставим территорию Вашего объекта чистой
                  </p>
                </div>
              </div>
              <div class="reason_slot">
                <div class="reason_slot__left">
                  <img src="public/src/img/icons/calendar_check.svg" />
                </div>
                <div class="reason_slot__right">
                  <h4>Удобный график</h4>
                  <p>
                    Мы понимаем, что иногда вывоз мусора требуется срочно.
                    Поэтому работаем для Вас в выходные и праздничные дни
                  </p>
                </div>
              </div>
              <div class="reason_slot">
                <div class="reason_slot__left">
                  <img src="public/src/img/icons/message_dots_circle.svg" />
                </div>
                <div class="reason_slot__right">
                  <h4>Уведомления</h4>
                  <p>
                    Держим в курсе о выезде автомобиля в Вашу сторону. Вся
                    коммуникация в удобном формате – по телефону и смс
                  </p>
                </div>
              </div>
              <div class="reason_slot">
                <div class="reason_slot__left">
                  <img src="public/src/img/icons/tag.svg" />
                </div>
                <div class="reason_slot__right">
                  <h4>Низкие цены</h4>
                  <p>
                    Стоимость наших услуг в среднем на 20% ниже, чем у
                    конкурентов. Поэтому с нами выгодно сотрудничать
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div class="center_panel">
          <!-- types waste -->
          <a name="types_waste"></a>
          <section class="types_waste_section">
            <h2>Какие виды отходов мы вывозим в контейнерах</h2>
            <div class="types_waste__slots">
              <div class="types_waste__slot types_waste__slot_2">
                <div class="garbage_1_wrapper">
                  <img src="public/src/img/pictures/garbage_1.png" />
                </div>
                <div class="types_waste__slot__wrapper">
                  <div class="types_waste__slot__panel">
                    <div class="types_waste__slot__panel__wrapper__img">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Строительный мусор</label>
                    <p>
                      Строительный материал, элементы конструкций, оставшиеся
                      после демонтажа, перепланировки, возведения зданий,
                      капремонта помещений
                    </p>
                  </div>
                </div>
              </div>
              <div class="types_waste__slot">
                <div class="types_waste__slot__wrapper">
                  <div class="types_waste__slot__panel">
                    <div class="types_waste__slot__panel__wrapper__img">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Отходы производства</label>
                    <p>
                      Мусор, образовавшийся в процессе производства. Например,
                      стружка, пластик, расходные материалы, старое оборудование
                    </p>
                  </div>
                </div>
              </div>
              <div class="types_waste__slot">
                <div class="types_waste__slot__wrapper">
                  <div class="types_waste__slot__panel">
                    <div class="types_waste__slot__panel__wrapper__img">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Старая мебель</label>
                    <p>
                      Шкафы, стеллажи, диваны, столы и другие крупногабаритные
                      предметы мебели, подлежащие утилизации
                    </p>
                  </div>
                </div>
              </div>
              <div class="types_waste__slot">
                <div class="types_waste__slot__wrapper">
                  <div class="types_waste__slot__panel">
                    <div class="types_waste__slot__panel__wrapper__img">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Макулатура</label>
                    <p>
                      Старая картонная или прочая тара (например, картонные
                      втулки, коробки и др.) в любых объемах
                    </p>
                  </div>
                </div>
              </div>
              <div class="types_waste__slot">
                <div class="types_waste__slot__wrapper">
                  <div class="types_waste__slot__panel">
                    <div class="types_waste__slot__panel__wrapper__img">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Дачный мусор</label>
                    <p>
                      Отходы, оставшиеся после выполнения работ на придомовой
                      территории, либо садовом участке
                    </p>
                  </div>
                </div>
              </div>
              <div class="types_waste__slot types_waste__slot_2">
                <div class="logs_wrapper">
                  <img src="public/src/img/pictures/logs.png" />
                </div>
                <div class="types_waste__slot__wrapper">
                  <div class="types_waste__slot__panel">
                    <div class="types_waste__slot__panel__wrapper__img">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Древесина, ветки</label>
                    <p>
                      Мусор, образовавшийся после обрезки или распила деревьев,
                      кустов, живых изгородей, в том числе сухие листья
                    </p>
                  </div>
                </div>
              </div>
              <div class="types_waste__slot types_waste__slot_3">
                <div class="fridge_wrapper">
                  <img src="public/src/img/pictures/fridge.png" />
                </div>
                <div class="types_waste__slot__wrapper">
                  <div class="types_waste__slot__panel">
                    <div class="types_waste__slot__panel__wrapper__img">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Бытовой крупногабаритный мусор</label>
                    <p>
                      Бытовая техника, сантехника и другие крупногабаритные
                      вещи, не подлежащие утилизации на придомовых контейнерных
                      площадках для сбора ТБО
                    </p>
                  </div>
                </div>
                <div class="types_waste__slot_3__btn">
                  <a onclick="setVisibleLeaveRequestPanel(true)" class="btn">Оставить заявку</a>
                </div>
              </div>
              <div class="types_waste__slot">
                <div class="types_waste__slot__wrapper">
                  <div class="types_waste__slot__panel">
                    <div class="types_waste__slot__panel__wrapper__img">
                      <img src="public/src/img/icons/ok.svg" />
                    </div>
                    <label>Снег</label>
                    <p>
                      Снег, оставшийся во дворах, на парковках, стройплощадках и
                      других частных территориях после механизированной или
                      ручной уборки
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <!-- which container -->
          <a name="which_container"></a>
          <section class="which_container_section">
            <div class="which_container_section__wrapper">
              <div class="which_container_section__wrapper__top">
                <h3>
                  Какой контейнер подойдет для вывоза мусора в Вашем случае?
                </h3>
                <p>
                  Расскажите, какие виды отходов необходимо вывезти, а мы
                  предложим Вам подходящий контейнер
                </p>
                <label>+7 (4012) 520-510</label>
              </div>
              <div class="which_container_section__wrapper__bottom">
                <div class="which_container_section__wrapper__bottom__img">
                  <img src="public/src/img/logos/telegram.svg" />
                </div>
                <label>Или напишите нам в мессенджере</label>
              </div>
              <div class="which_container_section__wrapper__img">
                <img src="public/src/img/pictures/garbage_2.png" />
              </div>
            </div>
          </section>
        </div>
        <!-- reasons apply -->
        <a name="reasons_apply"></a>
        <section class="reasons_section">
          <div class="center_panel reasons_section__wrapper reasons_apply">
            <h3>Оформить заявку — просто и быстро</h3>
            <div class="reasons_apply__slots">
              <div class="reason_apply_slot">
                <div class="reason_apply_slot__img">
                  <img src="public/src/img/icons/number_01.svg" />
                </div>
                <div class="reason_apply_slot_wrap">
                  <label class="reason_apply_slot__title">Заявка</label>
                  <label class="reason_apply_slot__number">
                    +7 (4012) 520-510
                  </label>
                  <p class="reason_apply_slot__p">
                    Позвоните нам или отправив запрос через форму на сайте
                  </p>
                </div>
              </div>
              <div class="reason_apply_slot">
                <div class="reason_apply_slot__img">
                  <img src="public/src/img/icons/number_02.svg" />
                </div>
                <div class="reason_apply_slot_wrap">
                  <label class="reason_apply_slot__title">
                    Расчет стоимости
                  </label>
                  <p class="reason_apply_slot__p">
                    Специалисты сразу предложат выгодную цену исходя из объема и
                    расстояния
                  </p>
                </div>
              </div>
              <div class="reason_apply_slot">
                <div class="reason_apply_slot__img">
                  <img src="public/src/img/icons/number_03.svg" />
                </div>
                <div class="reason_apply_slot_wrap">
                  <label class="reason_apply_slot__title">Вывоз мусора</label>
                  <p class="reason_apply_slot__p">
                    Мы аккуратно произведем сбор и вывезем весь мусор вовремя в
                    оговоренные сроки.
                  </p>
                </div>
              </div>
              <div class="reason_apply_slot">
                <div class="reason_apply_slot__img">
                  <img src="public/src/img/icons/number_04.svg" />
                </div>
                <div class="reason_apply_slot_wrap">
                  <label class="reason_apply_slot__title">
                    Заключение договора
                  </label>
                  <p class="reason_apply_slot__p">
                    Оплата любым удобным для Вас способом по фиксированной
                    стоимости
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <div class="center_panel">
          <!-- answers -->
          <a name="answers"></a>
          <section class="answers_section answers_section__text">
            <h3>Отзывы</h3>
          </section>
        </div>
        <section class="center_panel answers_section answers_section_marg">
          <div
            class="itc-slider"
            data-slider="itc-slider"
            data-loop="true"
            data-autoplay="false"
          >
            <div class="itc-slider-wrapper">
              <div class="itc-slider-items">
                <div class="itc-slider-item">
                  <div class="answer_slot">
                    <div class="answer_slot__img">
                      <img src="public/src/img/pictures/telegram_chat.png" />
                    </div>
                  </div>
                </div>
                <div class="itc-slider-item">
                  <div class="answer_slot">
                    <div class="answer_slot__img">
                      <img src="public/src/img/pictures/telegram_chat.png" />
                    </div>
                  </div>
                </div>
                <div class="itc-slider-item">
                  <div class="answer_slot">
                    <div class="answer_slot__img">
                      <img src="public/src/img/pictures/telegram_chat.png" />
                    </div>
                  </div>
                </div>
                <div class="itc-slider-item">
                  <div class="answer_slot">
                    <div class="answer_slot__img">
                      <img src="public/src/img/pictures/telegram_chat.png" />
                    </div>
                  </div>
                </div>
                <div class="itc-slider-item">
                  <div class="answer_slot">
                    <div class="answer_slot__img">
                      <img src="public/src/img/pictures/telegram_chat.png" />
                    </div>
                  </div>
                </div>
                <div class="itc-slider-item">
                  <div class="answer_slot">
                    <div class="answer_slot__img">
                      <img src="public/src/img/pictures/telegram_chat.png" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <button class="itc-slider-btn itc-slider-btn-prev">
              <img src="public/src/img/icons/arrow_left.svg" />
            </button>
            <button class="itc-slider-btn itc-slider-btn-next">
              <img src="public/src/img/icons/arrow_right.svg" />
            </button>
          </div>
        </section>
        <div class="center_panel">
          <!-- additional services -->
          <a name="additional_services"></a>
          <section class="additional_services_services">
            <h3 class="additional_services_services__title">
              Дополнительные услуги
            </h3>
            <div class="additional_services__slots">
              <div class="additional_service_slot">
                <div class="additional_service_slot__wrapper">
                  <div class="additional_service_slot__top">
                    <h3>Услуги илососа</h3>
                    <p>
                      Чистка колодцев, жироуловителей, автомоек и канализаций в
                      Калининграде и области
                    </p>
                  </div>
                  <div class="additional_service_slot__btn">
                    <a onclick="setVisibleLeaveRequestPanel(true, true)" class="btn">Оставить заявку</a>
                  </div>
                  <div class="additional_service_slot__img_tree">
                    <img src="public/src/img/pictures/tree_5.png" />
                  </div>
                  <div class="additional_service_slot__img">
                    <img src="public/src/img/pictures/auto_6.png" />
                  </div>
                </div>
              </div>
              <div class="additional_service_slot">
                <div class="additional_service_slot__wrapper">
                  <div class="additional_service_slot__top">
                    <h3>Ассенизатор</h3>
                    <p>
                      Откачка септиков, выгребных ям, колодцев. Устраним засоры
                      и причины подтопления
                    </p>
                  </div>
                  <div class="additional_service_slot__btn">
                    <a onclick="setVisibleLeaveRequestPanel(true, true)" class="btn">Оставить заявку</a>
                  </div>
                  <div class="additional_service_slot__img_tree">
                    <img src="public/src/img/pictures/tree_5.png" />
                  </div>
                  <div class="additional_service_slot__img">
                    <img src="public/src/img/pictures/auto_7.png" />
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        <div class="center_panel">
          <!-- car park -->
          <div class="car_park_sections ccar_park_sections__title">
            <a name="car_park"></a>
            <h3>Собственный автопарк</h3>
          </div>
        </div>
        <div class="center_panel car_park_sections_mrg">
          <div class="car_park_sections">
            <div
              class="itc-slider"
              data-slider="itc-slider"
              data-loop="true"
              data-autoplay="false"
            >
              <div class="itc-slider-wrapper">
                <div class="itc-slider-items">
                  <div class="itc-slider-item">
                    <div class="car_slot">
                      <img src="public/src/img/pictures/auto_3.png" />
                    </div>
                  </div>
                  <div class="itc-slider-item">
                    <div class="car_slot">
                      <img src="public/src/img/pictures/auto_3.png" />
                    </div>
                  </div>
                  <div class="itc-slider-item">
                    <div class="car_slot">
                      <img src="public/src/img/pictures/auto_3.png" />
                    </div>
                  </div>
                  <div class="itc-slider-item">
                    <div class="car_slot">
                      <img src="public/src/img/pictures/auto_3.png" />
                    </div>
                  </div>
                  <div class="itc-slider-item">
                    <div class="car_slot">
                      <img src="public/src/img/pictures/auto_3.png" />
                    </div>
                  </div>
                  <div class="itc-slider-item">
                    <div class="car_slot">
                      <img src="public/src/img/pictures/auto_3.png" />
                    </div>
                  </div>
                </div>
              </div>
              <button class="itc-slider-btn itc-slider-btn-prev">
                <img src="public/src/img/icons/arrow_left.svg" />
              </button>
              <button class="itc-slider-btn itc-slider-btn-next">
                <img src="public/src/img/icons/arrow_right.svg" />
              </button>
            </div>
          </div>
        </div>
        <div class="center_panel">
          <!-- more about -->
          <a name="more_about"></a>
          <section class="more_about_section">
            <h3>Подробнее об услуге</h3>
            <p>
              Для Вашего комфорта - комплексная организация всего процесса,
              начиная с оперативного приема заявки, расчета стоимости, и
              согласования удобного графика вывоза мусора. Специалисты
              произведут сбор, погрузку и вывоз ТБО, строительного мусора,
              старой техники, древесины и прочих видов отходов недорого.
              Компания располагает собственным автопарком спецтехники с
              погрузчиками, контейнеровозами и прочими спецмашинами, а также в
              наличии современные и экологичные контейнеры объемом от 7 до 30
              м3.
            </p>
            <div class="more_about_section_list">
              <h4>Мы вывозим мусор со следующих объектов:</h4>
              <ul class="more_about_section_list__ul">
                <li class="more_about_section_list__li">
                  <div class="more_about_section_list__img">
                    <img src="public/src/img/icons/ellipse_point.svg" />
                  </div>
                  <label>Строительные площадки;</label>
                </li>
                <li class="more_about_section_list__li">
                  <div class="more_about_section_list__img">
                    <img src="public/src/img/icons/ellipse_point.svg" />
                  </div>
                  <label>Квартиры и коммерческие помещения;</label>
                </li>
                <li class="more_about_section_list__li">
                  <div class="more_about_section_list__img">
                    <img src="public/src/img/icons/ellipse_point.svg" />
                  </div>
                  <label>Территории СНТ и коттеджные участки</label>
                </li>
                <li class="more_about_section_list__li">
                  <div class="more_about_section_list__img">
                    <img src="public/src/img/icons/ellipse_point.svg" />
                  </div>
                  <label>Прочие частные территории</label>
                </li>
              </ul>
            </div>
            <p>
              Наша компания специализируется на вывозе мусора и мы гарантируем
              оперативное выполнение услуги и быструю подачу спецтехники. Во
              время сбора, вывоза, а также утилизации различных отходов
              придерживаемся актуальных санитарно-эпидемиологических норм. У нас
              действуют фиксированные расценки за вывоз 1 м3 мусора, однако,
              есть факторы, которые влияют на стоимость услуг. В том числе,
              характеристики отходов, удаленность объекта, а также потребность в
              мешках для сбора мусора
            </p>
            <p>
              Сотрудничать с нами удобно, ведь все наши сотрудники обучены и
              имеют большой опыт в данной сфере. Мы готовы работать с Вами на
              индивидуальных условиях
            </p>
          </section>

          <!-- other questions -->
          <a name="other_questions"></a>
          <section class="which_container_section">
            <div class="which_container_section__wrapper">
              <div class="which_container_section__wrapper__top">
                <h3>Остались вопросы? Оставьте заявку</h3>
                <p>
                  Расскажите, с какого объекта нужно вывезти отходы.
                  Охарактеризуйте мусор (укажите его тип, примерный вес и
                  габариты). Мы свяжемся с Вами и предложим лучшее решение.
                </p>
              </div>
              <div class="which_container_section__wrapper__bottom">
                <div class="other_questions_btn">
                  <a onclick="setVisibleLeaveRequestPanel(true)" class="btn">Оставить заявку</a>
                </div>
              </div>
              <div
                class="which_container_section__wrapper__img which_container_section__wrapper__img_container"
              >
                <img src="public/src/img/pictures/container.png" />
              </div>
            </div>
          </section>
        </div>
      </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\pars.loc\resources\views/index.blade.php ENDPATH**/ ?>